#!/bin/bash
if [ "$EUID" -ne 0 ]
  then echo "Script to be run as root (or with sudo)!"
  exit
fi
clear

echo "XDRD_installer - tested on Ubuntu!"
read -p "Press enter to start the installation!"
	echo "Updating ..."
	sudo apt update &> /dev/null
	echo "Done ! Installing icecast2 ..."
	sudo apt install icecast2 -y &> /dev/null
	echo "Done ! Installing darkice ..."
	sudo apt install darkice -y &> /dev/null
	echo "Done ! Installing wget ..."
	sudo apt install wget -y &> /dev/null
	echo "Done ! Installing unzip ..."
	sudo apt install unzip -y &> /dev/null
	echo "Done ! Installing openssl ..."
	sudo apt install openssl -y &> /dev/null
	echo "Done ! Installing gcc ..."
	sudo apt install gcc -y &> /dev/null
	echo "Done ! Installing libraries ..."
	sudo apt install libssl-dev -y &> /dev/null
	echo "Done ! Installing make..."
	sudo apt install make -y &> /dev/null
clear

echo "Downloading XDRD ..."
	cd /home
    wget https://github.com/RTVDXRO/XDRD_installer/raw/master/master.zip
	unzip master.zip
	#rm master.zip
	cd xdrd-master
        chmod +x start.sh

echo "Done ! Compiling..."
	make -f Makefile  &> /dev/null
	gcc -o xdrd xdrd.o -lpthread -lcrypto

echo "Configuring ..."
cd /etc/systemd/system
touch xdrd-tcp.service
echo "
[Unit]
Description=XDRD-TCP Service
[Service]
ExecStart=/home/xdrd-master/start.sh start
ExecStop=/home/xdrd-master/start.sh stop
[Install]
WantedBy=multi-user.target
	" > xdrd-tcp.service
echo " "

echo "Start XDRD on boot"
	systemctl enable xdrd-tcp.service
	echo " "
	echo "Start on boot enabled ! Continuing..."
echo " "

echo "XDRD has been installed !"
echo "Don't forget to configure your Icecast2, Darkice and also start.sh ( /home/xdrd-master )"
echo "then execute ./start.sh in directory /home/xdrd-master or use systemctl start xdr-tcp.service"
read -p "Hit enter to finish the installation & Happy DX-ing!"
