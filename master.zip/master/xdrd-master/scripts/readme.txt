Don't forget to configure first your Icecast2 & Darkice for best streaming of your audio input 
then execute ./start.sh in directory /home/xdrd-master .
Or use systemctl start xdrd-tcp.service.