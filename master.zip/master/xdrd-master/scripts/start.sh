PORT="7777"
PASSWORD="7777"
MAXUSERS="1"
DIR="/home/xdrd-master"

function startServer {
	if [ -d $DIR ]; then
		cd $DIR
		if [ -f "xdrd" ]; then
			screen -dmS xdr-tcp ./xdrd -t $PORT -u $MAXUSERS -p $PASSWORD 
			echo "Server started !"
		else
			echo "Error: XDRD executable not found !"
		fi
	else
		echo "Error: XDRD folder not found !"
	fi
}

function stopServer {
	CHECK=`ps u -C xdrd | grep -vc USER`
	if [ $CHECK -eq 0 ]; then
		echo "XDRD Server is currently not running."
	else
		killall $EXEC
		echo "XDRD Server stopped !"
	fi
}

function serverStatus {
	CHECK=`ps u -C xdrd | grep -vc USER`
	if [ $CHECK -eq 0 ]; then
		echo "XDRD Server is currently not running."
	else 
		echo "XDRD Server is running."
	fi
}

case "$1" in
	start)
		startServer
		;;

	stop)
		stopServer
		;;

	restart)
		stopServer
		sleep 1
		startServer
		;;

	status)
		serverStatus
		;;


	*)
		echo "Syntax: $0 [start|stop|restart|status]"
		exit 1
		;;
		
esac
exit
