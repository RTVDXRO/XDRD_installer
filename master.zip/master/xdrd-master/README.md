# XDRD_installer
 XDRD is a server for XDR/NXP-GTK interface ( Linux or Windows ) ( https://github.com/kkonradpl/xdrd.git )
- Thanks to Konrad Kosmatka for his great work !
- This script installs xdrd as root, runs it as root, enables it to start at boot.
- Save this script to a file (e.g., xdrd_installer.sh), then make it executable: chmod +x xdrd_installer.sh
- Run the script with root privileges: sudo ./xdrd_installer.sh
- Don't forget to configure first start.sh & IceCast2, Darkice for audio streaming!
- Tested on Ubuntu only !